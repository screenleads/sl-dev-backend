package com.screenleads.backend.app.web.dto;

public record DeviceTypeDTO(Long id, String type, Boolean enabled) {
}
