package com.screenleads.backend.app.web.dto;

public record PromotionDTO(Long id, String legal_url, String description) {
}
