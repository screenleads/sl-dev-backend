package com.screenleads.backend.app.web.dto;

public record MediaTypeDTO(Long id, String extension, String type, Boolean enabled) {
}
