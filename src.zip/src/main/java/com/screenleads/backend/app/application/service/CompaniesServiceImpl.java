package com.screenleads.backend.app.application.service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.screenleads.backend.app.domain.model.Advice;
import com.screenleads.backend.app.domain.model.Company;
import com.screenleads.backend.app.domain.model.Device;
import com.screenleads.backend.app.domain.model.Media;
import com.screenleads.backend.app.domain.repositories.*;
import com.screenleads.backend.app.web.dto.CompanyDTO;

@Service
public class CompaniesServiceImpl implements CompaniesService {

    private final MediaTypeRepository mediaTypeRepository;

    private final CompanyRepository companyRepository;
    private final MediaRepository mediaRepository;
    private final AdviceRepository adviceRepository;
    private final DeviceRepository deviceRepository;

    public CompaniesServiceImpl(CompanyRepository companyRepository, MediaRepository mediaRepository,
            AdviceRepository adviceRepository, DeviceRepository deviceRepository,
            MediaTypeRepository mediaTypeRepository) {
        this.companyRepository = companyRepository;
        this.mediaRepository = mediaRepository;
        this.adviceRepository = adviceRepository;
        this.deviceRepository = deviceRepository;
        this.mediaTypeRepository = mediaTypeRepository;
    }

    @Override
    public List<CompanyDTO> getAllCompanies() {
        return companyRepository.findAll().stream()
                .map(this::convertToDTO)
                .sorted(Comparator.comparing(CompanyDTO::id))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<CompanyDTO> getCompanyById(Long id) {
        return companyRepository.findById(id).map(this::convertToDTO);
    }

    @Override
    public CompanyDTO saveCompany(CompanyDTO companyDTO) {
        Company company = convertToEntity(companyDTO);

        // Si ya existe por nombre, devolver el existente
        Optional<Company> exist = companyRepository.findByName(company.getName());
        if (exist.isPresent()) {
            return convertToDTO(exist.get());
        }

        // --- Manejo del logo ---
        if (companyDTO.logo() != null) {
            if (companyDTO.logo().getId() != null) {
                // Buscar el Media existente por id
                Media media = mediaRepository.findById(companyDTO.logo().getId())
                        .orElseThrow(
                                () -> new RuntimeException("Media no encontrado con id: " + companyDTO.logo().getId()));
                company.setLogo(media);

            } else if (companyDTO.logo().getSrc() != null && !companyDTO.logo().getSrc().isBlank()) {
                // Crear un nuevo Media con el src
                Media newLogo = new Media();
                newLogo.setSrc(companyDTO.logo().getSrc());

                // Detectar extensión
                String srcLower = companyDTO.logo().getSrc().toLowerCase();
                String extension = null;
                int dotIndex = srcLower.lastIndexOf('.');
                if (dotIndex != -1 && dotIndex < srcLower.length() - 1) {
                    extension = srcLower.substring(dotIndex + 1);
                }

                // Asignar MediaType según extensión
                if (extension != null) {
                    mediaTypeRepository.findByExtension(extension).ifPresent(newLogo::setType);
                }

                Media savedLogo = mediaRepository.save(newLogo);
                company.setLogo(savedLogo);

            } else {
                company.setLogo(null);
            }
        } else {
            company.setLogo(null);
        }

        Company savedCompany = companyRepository.save(company);
        return convertToDTO(savedCompany);
    }

    @Override
    public CompanyDTO updateCompany(Long id, CompanyDTO companyDTO) {
        Company company = companyRepository.findById(id).orElseThrow();
        company.setName(companyDTO.name());
        company.setObservations(companyDTO.observations());
        company.setPrimaryColor(companyDTO.primaryColor());
        company.setSecondaryColor(companyDTO.secondaryColor());

        // Manejo seguro del logo
        if (companyDTO.logo() != null) {
            if (companyDTO.logo().getId() != null) {
                Media media = mediaRepository.findById(companyDTO.logo().getId()).orElseThrow();

                String newSrc = companyDTO.logo().getSrc();
                if (newSrc != null && !newSrc.isBlank() && !java.util.Objects.equals(media.getSrc(), newSrc)) {
                    media.setSrc(newSrc);
                    mediaRepository.save(media);
                }

                company.setLogo(media);

            } else if (companyDTO.logo().getSrc() != null && !companyDTO.logo().getSrc().isBlank()) {
                // Crear nuevo Media desde cero
                Media newLogo = new Media();
                newLogo.setSrc(companyDTO.logo().getSrc());
                String srcLower = companyDTO.logo().getSrc().toLowerCase();
                String extension = null;
                int dotIndex = srcLower.lastIndexOf('.');
                if (dotIndex != -1 && dotIndex < srcLower.length() - 1) {
                    extension = srcLower.substring(dotIndex + 1);
                }

                // Asignar MediaType según extensión
                if (extension != null) {
                    mediaTypeRepository.findByExtension(extension).ifPresent(newLogo::setType);
                }
                Media savedLogo = mediaRepository.save(newLogo);
                company.setLogo(savedLogo);

            } else {
                company.setLogo(null);
            }
        } else {
            company.setLogo(null);
        }

        Company updatedCompany = companyRepository.save(company);
        return convertToDTO(updatedCompany);
    }

    @Override
    public void deleteCompany(Long id) {
        companyRepository.deleteById(id);
    }

    private CompanyDTO convertToDTO(Company company) {
        return new CompanyDTO(
                company.getId(),
                company.getName(),
                company.getObservations(),
                company.getLogo(),
                company.getDevices(),
                company.getAdvices(),
                company.getPrimaryColor(),
                company.getSecondaryColor());
    }

    private Company convertToEntity(CompanyDTO companyDTO) {
        Company company = new Company();
        company.setId(companyDTO.id());
        company.setName(companyDTO.name());
        company.setPrimaryColor(companyDTO.primaryColor());
        company.setSecondaryColor(companyDTO.secondaryColor());
        company.setObservations(companyDTO.observations());

        // Manejo seguro del logo
        if (companyDTO.logo() != null && companyDTO.logo().getId() != null) {
            mediaRepository.findById(companyDTO.logo().getId()).ifPresent(company::setLogo);
        } else {
            company.setLogo(null);
        }

        if (companyDTO.advices() != null) {
            List<Advice> advices = companyDTO.advices().stream()
                    .map(adviceDTO -> adviceRepository.findById(adviceDTO.getId()).orElse(null))
                    .filter(a -> a != null)
                    .peek(a -> a.setCompany(company))
                    .collect(Collectors.toList());
            company.setAdvices(advices);
        } else {
            company.setAdvices(List.of());
        }

        if (companyDTO.devices() != null) {
            List<Device> devices = companyDTO.devices().stream()
                    .map(deviceDTO -> deviceRepository.findById(deviceDTO.getId()).orElse(null))
                    .filter(d -> d != null)
                    .peek(d -> d.setCompany(company))
                    .collect(Collectors.toList());
            company.setDevices(devices);
        } else {
            company.setDevices(List.of());
        }

        return company;
    }
}
